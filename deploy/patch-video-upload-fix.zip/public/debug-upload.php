<?php

declare(strict_types=1);

const DEBUG_KEY = 'ck2026fix';

if (($_GET['key'] ?? '') !== DEBUG_KEY) {
    http_response_code(404);
    exit('Not found');
}

header('Content-Type: text/plain; charset=utf-8');

$root = dirname(__DIR__);

echo "=== CEK LIMIT UPLOAD PHP ===\n\n";
$keys = ['upload_max_filesize', 'post_max_size', 'max_execution_time', 'memory_limit', 'file_uploads'];
foreach ($keys as $key) {
    echo str_pad($key, 22).': '.ini_get($key)."\n";
}

echo "\n=== CEK FOLDER UPLOAD ===\n";
$dirs = [
    'storage/app/public' => $root.'/storage/app/public',
    'storage/app/public/article-videos' => $root.'/storage/app/public/article-videos',
    'storage/app/public/article-covers' => $root.'/storage/app/public/article-covers',
];
foreach ($dirs as $label => $path) {
    $writable = is_dir($path) && is_writable($path);
    echo ($writable ? 'OK' : 'MISSING/LOCKED')." — {$label}\n";
}

echo "\n=== TES TULIS FILE ===\n";
$testFile = $root.'/storage/app/public/article-videos/.write-test-'.time().'.txt';
if (@file_put_contents($testFile, 'ok') !== false) {
    echo "OK — bisa menulis ke article-videos\n";
    @unlink($testFile);
} else {
    echo "GAGAL — tidak bisa menulis ke article-videos (permission)\n";
}

echo "\n=== SARAN ===\n";
$postMax = ini_get('post_max_size');
$uploadMax = ini_get('upload_max_filesize');
echo "- Video maksimal aman: lebih kecil dari upload_max_filesize ({$uploadMax})\n";
echo "- Jika limit 2M/8M, upload video besar akan gagal\n";
echo "- Pastikan public/.user.ini ada dan aktif (128M)\n";
echo "- Atau minta host naikkan post_max_size & upload_max_filesize\n";
echo "\nHapus debug-upload.php setelah dibaca.\n";
