<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HealthArticle;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class AdminArticleController extends Controller
{
    public function index(): View
    {
        $articles = HealthArticle::latest()->paginate(15);

        return view('admin.articles.index', compact('articles'));
    }

    public function create(Request $request): View
    {
        $type = $request->query('type') === 'video' ? 'video' : 'article';
        $article = new HealthArticle(['content_type' => $type]);

        return view('admin.articles.form', compact('article', 'type'));
    }

    public function store(Request $request): RedirectResponse
    {
        $type = $request->input('content_type', 'article') === 'video' ? 'video' : 'article';
        $validated = $this->validateArticle($request, $type);
        $validated['slug'] = Str::slug($validated['title']);
        $validated['content_type'] = $type;

        if ($request->hasFile('cover_image')) {
            $validated['cover_image'] = $this->storeCoverImage($request->file('cover_image'));
        }

        if ($type === 'video') {
            $validated['content'] = $validated['content'] ?? '';
            unset($validated['video_file']);
            $validated['video_url'] = $this->storeVideoFile($request->file('video_file'));
        }

        HealthArticle::create($validated);

        $label = $type === 'video' ? 'Video' : 'Artikel';

        return redirect()->route('admin.articles.index')->with('status', "{$label} berhasil ditambahkan.");
    }

    public function edit(HealthArticle $article): View
    {
        $type = $article->isVideo() ? 'video' : 'article';

        return view('admin.articles.form', compact('article', 'type'));
    }

    public function update(Request $request, HealthArticle $article): RedirectResponse
    {
        $type = $request->input('content_type', $article->content_type ?? 'article') === 'video' ? 'video' : 'article';
        $validated = $this->validateArticle($request, $type, $article);
        $validated['content_type'] = $type;

        if ($request->boolean('remove_cover_image') && $article->cover_image) {
            Storage::disk('public')->delete($article->cover_image);
            $validated['cover_image'] = null;
        }

        if ($request->hasFile('cover_image')) {
            if ($article->cover_image) {
                Storage::disk('public')->delete($article->cover_image);
            }

            $validated['cover_image'] = $this->storeCoverImage($request->file('cover_image'));
        }

        if ($type === 'video') {
            $validated['content'] = $validated['content'] ?? '';
            unset($validated['video_file']);

            if ($request->boolean('remove_video') && $article->video_url) {
                $this->deleteVideoFile($article->video_url);
                $validated['video_url'] = null;
            }

            if ($request->hasFile('video_file')) {
                if ($article->video_url) {
                    $this->deleteVideoFile($article->video_url);
                }

                $validated['video_url'] = $this->storeVideoFile($request->file('video_file'));
            }
        } else {
            if ($article->video_url) {
                $this->deleteVideoFile($article->video_url);
            }
            $validated['video_url'] = null;
        }

        $article->update($validated);

        $label = $type === 'video' ? 'Video' : 'Artikel';

        return redirect()->route('admin.articles.index')->with('status', "{$label} berhasil diperbarui.");
    }

    public function destroy(HealthArticle $article): RedirectResponse
    {
        if ($article->cover_image) {
            Storage::disk('public')->delete($article->cover_image);
        }

        if ($article->video_url) {
            $this->deleteVideoFile($article->video_url);
        }

        $article->delete();

        return redirect()->route('admin.articles.index')->with('status', 'Konten berhasil dihapus.');
    }

    private function storeCoverImage(UploadedFile $file): string
    {
        return $file->store('article-covers', 'public');
    }

    private function storeVideoFile(UploadedFile $file): string
    {
        return $file->store('article-videos', 'public');
    }

    private function deleteVideoFile(string $path): void
    {
        if (! str_starts_with($path, 'http') && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function validateArticle(Request $request, string $type, ?HealthArticle $article = null): array
    {
        $rules = [
            'title' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:50'],
            'cover_image' => ['nullable', 'image', 'mimes:jpeg,jpg,png,webp', 'max:2048'],
            'excerpt' => ['required', 'string', 'max:500'],
            'is_published' => ['sometimes', 'boolean'],
            'remove_cover_image' => ['sometimes', 'boolean'],
            'content_type' => ['required', 'in:article,video'],
        ];

        if ($type === 'video') {
            $hasExistingVideo = $article?->video_url && ! $request->boolean('remove_video');
            $rules['video_file'] = [
                $hasExistingVideo ? 'nullable' : 'required',
                'file',
                'mimes:mp4,webm,ogg,quicktime,mov',
                'max:81920',
            ];
            $rules['content'] = ['nullable', 'string'];
            $rules['remove_video'] = ['sometimes', 'boolean'];
        } else {
            $rules['content'] = ['required', 'string'];
        }

        return $request->validate($rules, [
            'cover_image.image' => 'File harus berupa gambar.',
            'cover_image.mimes' => 'Format foto: JPG, PNG, atau WebP.',
            'cover_image.max' => 'Ukuran foto maksimal 2 MB.',
            'video_file.required' => 'File video wajib diunggah.',
            'video_file.mimes' => 'Format video: MP4, WebM, OGG, atau MOV.',
            'video_file.max' => 'Ukuran video maksimal 80 MB.',
        ]) + ['is_published' => $request->boolean('is_published')];
    }
}
