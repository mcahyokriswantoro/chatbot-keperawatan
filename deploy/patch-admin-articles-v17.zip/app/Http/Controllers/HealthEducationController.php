<?php

namespace App\Http\Controllers;

use App\Models\HealthArticle;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\View\View;

class HealthEducationController extends Controller
{
    public function index(): View
    {
        $articles = $this->mapArticlesForView($this->publishedArticles());
        $categories = $this->buildCategoriesForView($articles);

        return view('education.index', [
            'articles' => $articles,
            'categories' => $categories,
            'featured' => $articles->first(),
        ]);
    }

    public function show(string $slug): View
    {
        $article = HealthArticle::query()
            ->where('slug', $slug)
            ->where('is_published', true)
            ->firstOrFail();

        return view('education.show', compact('article'));
    }

    /**
     * @return Collection<int, HealthArticle>
     */
    protected function publishedArticles(): Collection
    {
        if (! Schema::hasTable('health_articles')) {
            return collect();
        }

        return HealthArticle::query()
            ->where('is_published', true)
            ->latest()
            ->get();
    }

    /**
     * @param  Collection<int, HealthArticle>  $records
     * @return Collection<int, array<string, mixed>>
     */
    protected function mapArticlesForView(Collection $records): Collection
    {
        return $records->map(function (HealthArticle $article) {
            $isVideo = $article->isVideo();
            $categoryName = trim((string) $article->category) !== '' ? $article->category : 'Umum';
            $categoryId = 'cat-'.(Str::slug($categoryName) ?: 'umum');

            return [
                'slug' => $article->slug,
                'title' => $article->title,
                'excerpt' => $article->excerpt,
                'url' => route('education.show', $article->slug),
                'image' => $article->coverImageUrl() ?? asset('images/robot.png'),
                'read_min' => $isVideo ? 0 : max(1, (int) ceil(strlen(strip_tags($article->content ?? '')) / 1200)),
                'read_label' => $isVideo ? 'Video edukasi' : null,
                'tag' => $isVideo ? 'Video' : $categoryName,
                'category_id' => $categoryId,
                'category_name' => $categoryName,
                'category_icon' => $isVideo ? '▶️' : '📄',
                'category_chip' => $isVideo ? 'bg-violet-50 text-violet-700 ring-violet-200' : 'bg-brand-50 text-brand-700 ring-brand-200',
                'published_at' => $article->created_at?->translatedFormat('d M Y'),
                'is_video' => $isVideo,
            ];
        })->values();
    }

    /**
     * @param  Collection<int, array<string, mixed>>  $articles
     * @return Collection<int, array<string, mixed>>
     */
    protected function buildCategoriesForView(Collection $articles): Collection
    {
        $categories = collect();

        if ($articles->contains(fn (array $article) => $article['is_video'])) {
            $categories->push([
                'id' => 'video',
                'name' => 'Video',
                'icon' => '▶️',
                'chip' => 'bg-violet-50 text-violet-700 ring-violet-200',
            ]);
        }

        if ($articles->contains(fn (array $article) => ! $article['is_video'])) {
            $categories->push([
                'id' => 'article',
                'name' => 'Artikel',
                'icon' => '📄',
                'chip' => 'bg-brand-50 text-brand-700 ring-brand-200',
            ]);
        }

        foreach ($articles->unique('category_id') as $article) {
            $categories->push([
                'id' => $article['category_id'],
                'name' => $article['category_name'],
                'icon' => '📂',
                'chip' => 'bg-slate-50 text-slate-700 ring-slate-200',
            ]);
        }

        return $categories->unique('id')->values();
    }
}
